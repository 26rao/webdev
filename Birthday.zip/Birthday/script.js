let userName = "";
let customMessage = "";

function goToCake() {
  userName = document.getElementById("nameInput").value;
  customMessage = document.getElementById("customMsg").value;

  if (!userName || !customMessage) {
    alert("Please enter both name and message 💌");
    return;
  }

  document.getElementById("start-screen").style.display = "none";
  document.getElementById("cake-screen").style.display = "block";
  document.getElementById("displayName").innerText = userName;
}

function cutCake() {
  document.getElementById("cake-screen").style.display = "none";
  document.getElementById("greeting-card").style.display = "block";
  document.getElementById("cardName").innerText = userName;
  document.getElementById("finalMessage").innerText = customMessage;
}
