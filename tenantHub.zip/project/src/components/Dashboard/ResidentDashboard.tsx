import React, { useState, useEffect } from 'react';
import { 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  CreditCard, 
  FileText, 
  Upload,
  Bell,
  MessageSquare,
  DollarSign,
  Calendar,
  Plus
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import api from '../../utils/api';

interface ResidentDashboardProps {
  activeTab: string;
}

const ResidentDashboard: React.FC<ResidentDashboardProps> = ({ activeTab }) => {
  const { user } = useAuth();
  const [complaints, setComplaints] = useState([]);
  const [notices, setNotices] = useState([]);
  const [currentRent, setCurrentRent] = useState(null);
  const [rentHistory, setRentHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [newComplaint, setNewComplaint] = useState({
    title: '',
    category: '',
    urgency: 'medium',
    description: ''
  });

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const [complaintsRes, noticesRes, currentRentRes, rentHistoryRes] = await Promise.all([
        api.complaints.getAll(),
        api.notices.getAll({ active: true }),
        api.rent.getCurrent(),
        api.rent.getAll({ limit: 12 })
      ]);

      setComplaints(complaintsRes.complaints || []);
      setNotices(noticesRes.notices || []);
      setCurrentRent(currentRentRes.rentRecord);
      setRentHistory(rentHistoryRes.rentRecords || []);
    } catch (err: any) {
      setError(err.message || 'Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitComplaint = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.complaints.create(newComplaint);
      setNewComplaint({ title: '', category: '', urgency: 'medium', description: '' });
      loadDashboardData(); // Refresh complaints
    } catch (err: any) {
      setError(err.message || 'Failed to submit complaint');
    }
  };

  const handlePaymentProofUpload = async (rentId: string, file: File, paymentData: any) => {
    try {
      const formData = new FormData();
      formData.append('paymentProof', file);
      if (paymentData.transactionId) {
        formData.append('transactionId', paymentData.transactionId);
      }
      if (paymentData.paymentMethod) {
        formData.append('paymentMethod', paymentData.paymentMethod);
      }

      await api.rent.uploadPaymentProof(rentId, formData);
      loadDashboardData(); // Refresh rent data
    } catch (err: any) {
      setError(err.message || 'Failed to upload payment proof');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'in-progress': return 'bg-blue-100 text-blue-800';
      case 'resolved': return 'bg-green-100 text-green-800';
      case 'paid': return 'bg-green-100 text-green-800';
      case 'due': return 'bg-red-100 text-red-800';
      case 'overdue': return 'bg-red-200 text-red-900';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-orange-100 text-orange-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent"></div>
      </div>
    );
  }

  if (activeTab === 'dashboard') {
    return (
      <div>
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Dashboard</h1>
        
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-center">
            <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
            <span className="text-red-700">{error}</span>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Complaints</p>
                <p className="text-2xl font-bold text-gray-900">{complaints.length}</p>
              </div>
              <MessageSquare className="w-8 h-8 text-blue-600" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pending Issues</p>
                <p className="text-2xl font-bold text-orange-600">
                  {complaints.filter(c => c.status === 'pending').length}
                </p>
              </div>
              <Clock className="w-8 h-8 text-orange-600" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Rent Status</p>
                <p className="text-2xl font-bold text-red-600">
                  {currentRent?.status === 'paid' ? 'Paid' : 'Due'}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-red-600" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">New Notices</p>
                <p className="text-2xl font-bold text-blue-600">{notices.length}</p>
              </div>
              <Bell className="w-8 h-8 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Recent Complaints</h2>
            <div className="space-y-4">
              {complaints.slice(0, 3).map((complaint: any) => (
                <div key={complaint._id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-800">{complaint.title}</h3>
                    <p className="text-sm text-gray-600">{complaint.category}</p>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(complaint.status)}`}>
                    {complaint.status}
                  </span>
                </div>
              ))}
              {complaints.length === 0 && (
                <p className="text-gray-500 text-center py-4">No complaints submitted yet</p>
              )}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Latest Notices</h2>
            <div className="space-y-4">
              {notices.slice(0, 3).map((notice: any) => (
                <div key={notice._id} className="p-4 bg-gray-50 rounded-lg">
                  <h3 className="font-medium text-gray-800">{notice.title}</h3>
                  <p className="text-sm text-gray-600 mt-1">{notice.message}</p>
                  <p className="text-xs text-gray-500 mt-2">
                    {new Date(notice.createdAt).toLocaleDateString()}
                  </p>
                </div>
              ))}
              {notices.length === 0 && (
                <p className="text-gray-500 text-center py-4">No notices available</p>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (activeTab === 'complaints') {
    return (
      <div>
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Complaints</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h2 className="text-xl font-semibold text-gray-800 mb-6">Submit New Complaint</h2>
            <form onSubmit={handleSubmitComplaint} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                <input
                  type="text"
                  value={newComplaint.title}
                  onChange={(e) => setNewComplaint({ ...newComplaint, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Brief description of the issue"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select
                  value={newComplaint.category}
                  onChange={(e) => setNewComplaint({ ...newComplaint, category: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  required
                >
                  <option value="">Select category</option>
                  <option value="Plumbing">Plumbing</option>
                  <option value="Electrical">Electrical</option>
                  <option value="Maintenance">Maintenance</option>
                  <option value="Security">Security</option>
                  <option value="Parking">Parking</option>
                  <option value="Noise">Noise</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Urgency</label>
                <select
                  value={newComplaint.urgency}
                  onChange={(e) => setNewComplaint({ ...newComplaint, urgency: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea
                  value={newComplaint.description}
                  onChange={(e) => setNewComplaint({ ...newComplaint, description: e.target.value })}
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Detailed description of the issue"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center"
              >
                <Plus className="w-4 h-4 mr-2" />
                Submit Complaint
              </button>
            </form>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h2 className="text-xl font-semibold text-gray-800 mb-6">My Complaints</h2>
            <div className="space-y-4">
              {complaints.map((complaint: any) => (
                <div key={complaint._id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-medium text-gray-800">{complaint.title}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(complaint.status)}`}>
                      {complaint.status}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{complaint.description}</p>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">{complaint.category}</span>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 rounded text-xs ${getUrgencyColor(complaint.urgency)}`}>
                        {complaint.urgency}
                      </span>
                      <span className="text-gray-500">
                        {new Date(complaint.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  {complaint.response && (
                    <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                      <p className="text-sm text-blue-800">
                        <strong>Response:</strong> {complaint.response}
                      </p>
                    </div>
                  )}
                </div>
              ))}
              {complaints.length === 0 && (
                <p className="text-gray-500 text-center py-8">No complaints submitted yet</p>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (activeTab === 'rent') {
    return (
      <div>
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Rent & Payments</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h2 className="text-xl font-semibold text-gray-800 mb-6">Current Month</h2>
            {currentRent ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Month</span>
                  <span className="font-medium">{currentRent.month}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Amount</span>
                  <span className="font-medium text-lg">₹{currentRent.amount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Due Date</span>
                  <span className="font-medium">
                    {new Date(currentRent.dueDate).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Status</span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(currentRent.status)}`}>
                    {currentRent.status}
                  </span>
                </div>
                {currentRent.paidDate && (
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Paid Date</span>
                    <span className="font-medium">
                      {new Date(currentRent.paidDate).toLocaleDateString()}
                    </span>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">No rent record for current month</p>
            )}

            {currentRent && currentRent.status !== 'paid' && (
              <div className="mt-6 p-4 bg-orange-50 border border-orange-200 rounded-lg">
                <div className="flex items-center">
                  <AlertCircle className="w-5 h-5 text-orange-600 mr-2" />
                  <span className="text-orange-800 font-medium">Payment Due</span>
                </div>
                <p className="text-orange-700 text-sm mt-1">
                  Please upload payment proof after making the payment.
                </p>
              </div>
            )}
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h2 className="text-xl font-semibold text-gray-800 mb-6">Upload Payment Proof</h2>
            {currentRent && currentRent.status !== 'paid' ? (
              <PaymentProofUpload 
                rentId={currentRent._id}
                onUpload={handlePaymentProofUpload}
              />
            ) : (
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <p className="text-gray-600">Payment already completed</p>
              </div>
            )}
          </div>
        </div>

        <div className="mt-8 bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h2 className="text-xl font-semibold text-gray-800 mb-6">Payment History</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Month</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Amount</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Due Date</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Paid Date</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Status</th>
                </tr>
              </thead>
              <tbody>
                {rentHistory.map((rent: any) => (
                  <tr key={rent._id} className="border-b border-gray-100">
                    <td className="py-3 px-4">{rent.month}</td>
                    <td className="py-3 px-4">₹{rent.amount.toLocaleString()}</td>
                    <td className="py-3 px-4">
                      {new Date(rent.dueDate).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4">
                      {rent.paidDate ? new Date(rent.paidDate).toLocaleDateString() : '-'}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded-full text-sm ${getStatusColor(rent.status)}`}>
                        {rent.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {rentHistory.length === 0 && (
              <p className="text-gray-500 text-center py-8">No payment history available</p>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (activeTab === 'notices') {
    return (
      <div>
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Notices</h1>
        
        <div className="space-y-6">
          {notices.map((notice: any) => (
            <div key={notice._id} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    <h3 className="text-lg font-semibold text-gray-800">{notice.title}</h3>
                    <span className={`ml-3 px-2 py-1 rounded-full text-xs font-medium ${
                      notice.type === 'warning' ? 'bg-yellow-100 text-yellow-800' : 
                      notice.type === 'urgent' ? 'bg-red-100 text-red-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {notice.type}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-3">{notice.message}</p>
                  <div className="flex items-center text-sm text-gray-500">
                    <Calendar className="w-4 h-4 mr-1" />
                    {new Date(notice.createdAt).toLocaleDateString()}
                  </div>
                </div>
                <Bell className="w-5 h-5 text-gray-400" />
              </div>
            </div>
          ))}
          {notices.length === 0 && (
            <div className="bg-white rounded-xl shadow-sm p-12 border border-gray-100 text-center">
              <Bell className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No notices available</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return null;
};

// Payment Proof Upload Component
const PaymentProofUpload: React.FC<{
  rentId: string;
  onUpload: (rentId: string, file: File, paymentData: any) => void;
}> = ({ rentId, onUpload }) => {
  const [file, setFile] = useState<File | null>(null);
  const [paymentData, setPaymentData] = useState({
    transactionId: '',
    paymentMethod: 'online'
  });
  const [uploading, setUploading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    
    setUploading(true);
    try {
      await onUpload(rentId, file, paymentData);
      setFile(null);
      setPaymentData({ transactionId: '', paymentMethod: 'online' });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Payment Method
        </label>
        <select
          value={paymentData.paymentMethod}
          onChange={(e) => setPaymentData({ ...paymentData, paymentMethod: e.target.value })}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="online">Online Transfer</option>
          <option value="upi">UPI</option>
          <option value="bank_transfer">Bank Transfer</option>
          <option value="cheque">Cheque</option>
          <option value="cash">Cash</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Transaction ID (Optional)
        </label>
        <input
          type="text"
          value={paymentData.transactionId}
          onChange={(e) => setPaymentData({ ...paymentData, transactionId: e.target.value })}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Enter transaction ID"
        />
      </div>

      <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
        <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
        <p className="text-gray-600 mb-2">Upload payment screenshot or receipt</p>
        <p className="text-sm text-gray-500 mb-4">PNG, JPG or PDF up to 10MB</p>
        <input
          type="file"
          onChange={handleFileChange}
          accept="image/*,.pdf"
          className="hidden"
          id="payment-proof"
        />
        <label
          htmlFor="payment-proof"
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer inline-block"
        >
          Choose File
        </label>
        {file && (
          <p className="text-sm text-gray-600 mt-2">Selected: {file.name}</p>
        )}
      </div>

      {file && (
        <button
          onClick={handleUpload}
          disabled={uploading}
          className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
        >
          {uploading ? 'Uploading...' : 'Upload Payment Proof'}
        </button>
      )}
    </div>
  );
};

export default ResidentDashboard;