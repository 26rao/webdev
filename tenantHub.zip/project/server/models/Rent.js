import mongoose from 'mongoose';

const rentSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  amount: {
    type: Number,
    required: [true, 'Amount is required'],
    min: [0, 'Amount cannot be negative']
  },
  month: {
    type: String,
    required: [true, 'Month is required'],
    match: [/^\d{4}-(0[1-9]|1[0-2])$/, 'Month must be in YYYY-MM format']
  },
  dueDate: {
    type: Date,
    required: [true, 'Due date is required']
  },
  paidDate: {
    type: Date
  },
  status: {
    type: String,
    enum: ['due', 'paid', 'overdue'],
    default: 'due'
  },
  paymentProof: {
    type: String // URL to uploaded payment proof
  },
  paymentMethod: {
    type: String,
    enum: ['cash', 'bank_transfer', 'upi', 'cheque', 'online'],
    default: 'online'
  },
  transactionId: {
    type: String,
    trim: true
  },
  verifiedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  verifiedAt: {
    type: Date
  },
  notes: {
    type: String,
    trim: true,
    maxlength: [200, 'Notes cannot exceed 200 characters']
  }
}, {
  timestamps: true
});

// Compound index for user and month (unique combination)
rentSchema.index({ userId: 1, month: 1 }, { unique: true });

// Update status based on dates
rentSchema.pre('save', function(next) {
  const now = new Date();
  
  if (this.paidDate) {
    this.status = 'paid';
  } else if (this.dueDate < now) {
    this.status = 'overdue';
  } else {
    this.status = 'due';
  }
  
  next();
});

export default mongoose.model('Rent', rentSchema);