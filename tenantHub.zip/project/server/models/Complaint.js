import mongoose from 'mongoose';

const complaintSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Title is required'],
    trim: true,
    maxlength: [100, 'Title cannot exceed 100 characters']
  },
  description: {
    type: String,
    required: [true, 'Description is required'],
    trim: true,
    maxlength: [1000, 'Description cannot exceed 1000 characters']
  },
  category: {
    type: String,
    required: [true, 'Category is required'],
    enum: ['Plumbing', 'Electrical', 'Maintenance', 'Security', 'Parking', 'Noise', 'Other']
  },
  urgency: {
    type: String,
    required: [true, 'Urgency is required'],
    enum: ['low', 'medium', 'high'],
    default: 'medium'
  },
  status: {
    type: String,
    enum: ['pending', 'in-progress', 'resolved'],
    default: 'pending'
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  response: {
    type: String,
    trim: true,
    maxlength: [500, 'Response cannot exceed 500 characters']
  },
  images: [{
    type: String // URLs to uploaded images
  }],
  resolvedAt: {
    type: Date
  }
}, {
  timestamps: true
});

// Update resolvedAt when status changes to resolved
complaintSchema.pre('save', function(next) {
  if (this.isModified('status') && this.status === 'resolved') {
    this.resolvedAt = new Date();
  }
  next();
});

export default mongoose.model('Complaint', complaintSchema);