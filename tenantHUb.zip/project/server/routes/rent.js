import express from 'express';
import { body, validationResult, query } from 'express-validator';
import Rent from '../models/Rent.js';
import User from '../models/User.js';
import { authenticate, authorize } from '../middleware/auth.js';
import upload from '../middleware/upload.js';

const router = express.Router();

// Get rent records
router.get('/', authenticate, [
  query('month').optional().matches(/^\d{4}-(0[1-9]|1[0-2])$/),
  query('status').optional().isIn(['due', 'paid', 'overdue']),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { month, status, page = 1, limit = 10 } = req.query;
    const skip = (page - 1) * limit;

    // Build filter
    let filter = {};
    if (req.user.role === 'resident') {
      filter.userId = req.user._id;
    }
    if (month) filter.month = month;
    if (status) filter.status = status;

    const rentRecords = await Rent.find(filter)
      .populate('userId', 'name flatNo email')
      .populate('verifiedBy', 'name')
      .sort({ month: -1, createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Rent.countDocuments(filter);

    res.json({
      rentRecords,
      pagination: {
        current: parseInt(page),
        pages: Math.ceil(total / limit),
        total
      }
    });
  } catch (error) {
    console.error('Get rent records error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get current month rent status
router.get('/current', authenticate, async (req, res) => {
  try {
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM format
    
    let filter = { month: currentMonth };
    if (req.user.role === 'resident') {
      filter.userId = req.user._id;
    }

    const rentRecord = await Rent.findOne(filter)
      .populate('userId', 'name flatNo email')
      .populate('verifiedBy', 'name');

    res.json({ rentRecord });
  } catch (error) {
    console.error('Get current rent error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Create rent record (admin only)
router.post('/', authenticate, authorize('admin'), [
  body('userId').isMongoId().withMessage('Valid user ID is required'),
  body('amount').isFloat({ min: 0 }).withMessage('Amount must be a positive number'),
  body('month').matches(/^\d{4}-(0[1-9]|1[0-2])$/).withMessage('Month must be in YYYY-MM format'),
  body('dueDate').isISO8601().withMessage('Valid due date is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { userId, amount, month, dueDate } = req.body;

    // Check if user exists
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if rent record already exists for this user and month
    const existingRent = await Rent.findOne({ userId, month });
    if (existingRent) {
      return res.status(400).json({ message: 'Rent record already exists for this month' });
    }

    const rentRecord = new Rent({
      userId,
      amount,
      month,
      dueDate: new Date(dueDate)
    });

    await rentRecord.save();
    await rentRecord.populate('userId', 'name flatNo email');

    res.status(201).json({
      message: 'Rent record created successfully',
      rentRecord
    });
  } catch (error) {
    console.error('Create rent record error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Upload payment proof
router.post('/:id/payment-proof', authenticate, upload.single('paymentProof'), async (req, res) => {
  try {
    const rentRecord = await Rent.findById(req.params.id);
    if (!rentRecord) {
      return res.status(404).json({ message: 'Rent record not found' });
    }

    // Check if user can upload proof for this record
    if (req.user.role === 'resident' && rentRecord.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Access denied' });
    }

    if (!req.file) {
      return res.status(400).json({ message: 'Payment proof file is required' });
    }

    rentRecord.paymentProof = `/uploads/${req.file.filename}`;
    rentRecord.paidDate = new Date();
    
    // Add transaction ID and payment method if provided
    if (req.body.transactionId) {
      rentRecord.transactionId = req.body.transactionId;
    }
    if (req.body.paymentMethod) {
      rentRecord.paymentMethod = req.body.paymentMethod;
    }

    await rentRecord.save();
    await rentRecord.populate('userId', 'name flatNo email');

    res.json({
      message: 'Payment proof uploaded successfully',
      rentRecord
    });
  } catch (error) {
    console.error('Upload payment proof error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Verify payment (admin only)
router.put('/:id/verify', authenticate, authorize('admin'), [
  body('status').isIn(['paid', 'due']).withMessage('Status must be paid or due'),
  body('notes').optional().trim().isLength({ max: 200 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { status, notes } = req.body;
    
    const rentRecord = await Rent.findById(req.params.id);
    if (!rentRecord) {
      return res.status(404).json({ message: 'Rent record not found' });
    }

    rentRecord.status = status;
    if (notes) rentRecord.notes = notes;
    
    if (status === 'paid') {
      rentRecord.verifiedBy = req.user._id;
      rentRecord.verifiedAt = new Date();
      if (!rentRecord.paidDate) {
        rentRecord.paidDate = new Date();
      }
    } else {
      rentRecord.verifiedBy = undefined;
      rentRecord.verifiedAt = undefined;
    }

    await rentRecord.save();
    await rentRecord.populate(['userId', 'verifiedBy']);

    res.json({
      message: 'Payment verification updated successfully',
      rentRecord
    });
  } catch (error) {
    console.error('Verify payment error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get rent statistics (admin only)
router.get('/stats', authenticate, authorize('admin'), async (req, res) => {
  try {
    const currentMonth = new Date().toISOString().slice(0, 7);
    
    const stats = await Rent.aggregate([
      { $match: { month: currentMonth } },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 },
          totalAmount: { $sum: '$amount' }
        }
      }
    ]);

    const totalResidents = await User.countDocuments({ role: 'resident', isActive: true });
    const totalRentRecords = await Rent.countDocuments({ month: currentMonth });
    
    const formattedStats = {
      totalResidents,
      totalRentRecords,
      collectionRate: totalRentRecords > 0 ? ((stats.find(s => s._id === 'paid')?.count || 0) / totalRentRecords * 100).toFixed(1) : 0,
      statusBreakdown: stats.reduce((acc, stat) => {
        acc[stat._id] = {
          count: stat.count,
          totalAmount: stat.totalAmount
        };
        return acc;
      }, {})
    };

    res.json({ stats: formattedStats });
  } catch (error) {
    console.error('Get rent stats error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;