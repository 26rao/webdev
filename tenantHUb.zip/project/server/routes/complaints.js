import express from 'express';
import { body, validationResult, query } from 'express-validator';
import Complaint from '../models/Complaint.js';
import { authenticate, authorize } from '../middleware/auth.js';
import upload from '../middleware/upload.js';

const router = express.Router();

// Get all complaints (admin) or user's complaints (resident)
router.get('/', authenticate, [
  query('status').optional().isIn(['pending', 'in-progress', 'resolved']),
  query('category').optional().isIn(['Plumbing', 'Electrical', 'Maintenance', 'Security', 'Parking', 'Noise', 'Other']),
  query('urgency').optional().isIn(['low', 'medium', 'high']),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { status, category, urgency, page = 1, limit = 10 } = req.query;
    const skip = (page - 1) * limit;

    // Build filter
    let filter = {};
    if (req.user.role === 'resident') {
      filter.userId = req.user._id;
    }
    if (status) filter.status = status;
    if (category) filter.category = category;
    if (urgency) filter.urgency = urgency;

    const complaints = await Complaint.find(filter)
      .populate('userId', 'name flatNo email')
      .populate('assignedTo', 'name')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Complaint.countDocuments(filter);

    res.json({
      complaints,
      pagination: {
        current: parseInt(page),
        pages: Math.ceil(total / limit),
        total
      }
    });
  } catch (error) {
    console.error('Get complaints error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get single complaint
router.get('/:id', authenticate, async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id)
      .populate('userId', 'name flatNo email')
      .populate('assignedTo', 'name');

    if (!complaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }

    // Check if user can access this complaint
    if (req.user.role === 'resident' && complaint.userId._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Access denied' });
    }

    res.json({ complaint });
  } catch (error) {
    console.error('Get complaint error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Create new complaint
router.post('/', authenticate, [
  body('title').trim().isLength({ min: 5, max: 100 }).withMessage('Title must be 5-100 characters'),
  body('description').trim().isLength({ min: 10, max: 1000 }).withMessage('Description must be 10-1000 characters'),
  body('category').isIn(['Plumbing', 'Electrical', 'Maintenance', 'Security', 'Parking', 'Noise', 'Other']),
  body('urgency').optional().isIn(['low', 'medium', 'high'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { title, description, category, urgency = 'medium' } = req.body;

    const complaint = new Complaint({
      title,
      description,
      category,
      urgency,
      userId: req.user._id
    });

    await complaint.save();
    await complaint.populate('userId', 'name flatNo email');

    res.status(201).json({
      message: 'Complaint submitted successfully',
      complaint
    });
  } catch (error) {
    console.error('Create complaint error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update complaint status (admin only)
router.put('/:id', authenticate, authorize('admin'), [
  body('status').optional().isIn(['pending', 'in-progress', 'resolved']),
  body('response').optional().trim().isLength({ max: 500 }),
  body('assignedTo').optional().isMongoId()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { status, response, assignedTo } = req.body;
    
    const complaint = await Complaint.findById(req.params.id);
    if (!complaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }

    if (status) complaint.status = status;
    if (response) complaint.response = response;
    if (assignedTo) complaint.assignedTo = assignedTo;

    await complaint.save();
    await complaint.populate(['userId', 'assignedTo']);

    res.json({
      message: 'Complaint updated successfully',
      complaint
    });
  } catch (error) {
    console.error('Update complaint error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Upload complaint images
router.post('/:id/images', authenticate, upload.array('images', 5), async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id);
    if (!complaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }

    // Check if user can upload to this complaint
    if (req.user.role === 'resident' && complaint.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Access denied' });
    }

    const imageUrls = req.files.map(file => `/uploads/${file.filename}`);
    complaint.images.push(...imageUrls);
    await complaint.save();

    res.json({
      message: 'Images uploaded successfully',
      images: imageUrls
    });
  } catch (error) {
    console.error('Upload images error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete complaint (admin only)
router.delete('/:id', authenticate, authorize('admin'), async (req, res) => {
  try {
    const complaint = await Complaint.findByIdAndDelete(req.params.id);
    if (!complaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }

    res.json({ message: 'Complaint deleted successfully' });
  } catch (error) {
    console.error('Delete complaint error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;