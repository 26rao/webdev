import express from 'express';
import { body, validationResult, query } from 'express-validator';
import Notice from '../models/Notice.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// Get all notices
router.get('/', authenticate, [
  query('type').optional().isIn(['info', 'warning', 'urgent']),
  query('active').optional().isBoolean(),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { type, active, page = 1, limit = 10 } = req.query;
    const skip = (page - 1) * limit;

    // Build filter
    let filter = {};
    if (type) filter.type = type;
    if (active !== undefined) filter.isActive = active === 'true';
    
    // Filter by target audience
    filter.$or = [
      { targetAudience: 'all' },
      { targetAudience: 'residents' },
      { targetAudience: 'specific', targetFlats: req.user.flatNo }
    ];

    // Filter out expired notices
    filter.$or.push({
      $or: [
        { expiryDate: { $exists: false } },
        { expiryDate: { $gte: new Date() } }
      ]
    });

    const notices = await Notice.find(filter)
      .populate('createdBy', 'name')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Notice.countDocuments(filter);

    res.json({
      notices,
      pagination: {
        current: parseInt(page),
        pages: Math.ceil(total / limit),
        total
      }
    });
  } catch (error) {
    console.error('Get notices error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get single notice
router.get('/:id', authenticate, async (req, res) => {
  try {
    const notice = await Notice.findById(req.params.id)
      .populate('createdBy', 'name');

    if (!notice) {
      return res.status(404).json({ message: 'Notice not found' });
    }

    // Check if user can access this notice
    const canAccess = notice.targetAudience === 'all' ||
                     notice.targetAudience === 'residents' ||
                     (notice.targetAudience === 'specific' && notice.targetFlats.includes(req.user.flatNo));

    if (!canAccess && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied' });
    }

    res.json({ notice });
  } catch (error) {
    console.error('Get notice error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Create new notice (admin only)
router.post('/', authenticate, authorize('admin'), [
  body('title').trim().isLength({ min: 5, max: 100 }).withMessage('Title must be 5-100 characters'),
  body('message').trim().isLength({ min: 10, max: 1000 }).withMessage('Message must be 10-1000 characters'),
  body('type').optional().isIn(['info', 'warning', 'urgent']),
  body('targetAudience').optional().isIn(['all', 'residents', 'specific']),
  body('targetFlats').optional().isArray(),
  body('expiryDate').optional().isISO8601()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { title, message, type = 'info', targetAudience = 'all', targetFlats, expiryDate } = req.body;

    const notice = new Notice({
      title,
      message,
      type,
      targetAudience,
      targetFlats: targetAudience === 'specific' ? targetFlats : [],
      expiryDate: expiryDate ? new Date(expiryDate) : undefined,
      createdBy: req.user._id
    });

    await notice.save();
    await notice.populate('createdBy', 'name');

    res.status(201).json({
      message: 'Notice created successfully',
      notice
    });
  } catch (error) {
    console.error('Create notice error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update notice (admin only)
router.put('/:id', authenticate, authorize('admin'), [
  body('title').optional().trim().isLength({ min: 5, max: 100 }),
  body('message').optional().trim().isLength({ min: 10, max: 1000 }),
  body('type').optional().isIn(['info', 'warning', 'urgent']),
  body('isActive').optional().isBoolean(),
  body('expiryDate').optional().isISO8601()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { title, message, type, isActive, expiryDate } = req.body;
    
    const notice = await Notice.findById(req.params.id);
    if (!notice) {
      return res.status(404).json({ message: 'Notice not found' });
    }

    if (title) notice.title = title;
    if (message) notice.message = message;
    if (type) notice.type = type;
    if (isActive !== undefined) notice.isActive = isActive;
    if (expiryDate) notice.expiryDate = new Date(expiryDate);

    await notice.save();
    await notice.populate('createdBy', 'name');

    res.json({
      message: 'Notice updated successfully',
      notice
    });
  } catch (error) {
    console.error('Update notice error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete notice (admin only)
router.delete('/:id', authenticate, authorize('admin'), async (req, res) => {
  try {
    const notice = await Notice.findByIdAndDelete(req.params.id);
    if (!notice) {
      return res.status(404).json({ message: 'Notice not found' });
    }

    res.json({ message: 'Notice deleted successfully' });
  } catch (error) {
    console.error('Delete notice error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;