import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import ResidentDashboard from './ResidentDashboard';
import AdminDashboard from './AdminDashboard';
import { LayoutDashboard, MessageSquare, CreditCard, Bell, Users, Settings } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  const residentTabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'complaints', label: 'Complaints', icon: MessageSquare },
    { id: 'rent', label: 'Rent & Payments', icon: CreditCard },
    { id: 'notices', label: 'Notices', icon: Bell }
  ];

  const adminTabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'complaints', label: 'Manage Complaints', icon: MessageSquare },
    { id: 'residents', label: 'Residents', icon: Users },
    { id: 'rent', label: 'Rent Management', icon: CreditCard },
    { id: 'notices', label: 'Notices', icon: Bell },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  const tabs = user?.role === 'admin' ? adminTabs : residentTabs;

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-800">
            {user?.role === 'admin' ? 'Admin Panel' : 'Resident Portal'}
          </h2>
        </div>
        
        <nav className="mt-6">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center px-6 py-3 text-left hover:bg-blue-50 transition-colors ${
                  activeTab === tab.id
                    ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-700'
                    : 'text-gray-600 hover:text-blue-700'
                }`}
              >
                <Icon className="w-5 h-5 mr-3" />
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {user?.role === 'admin' ? (
            <AdminDashboard activeTab={activeTab} />
          ) : (
            <ResidentDashboard activeTab={activeTab} />
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;