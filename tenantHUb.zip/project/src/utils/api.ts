// Use environment variable or fallback to localhost
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Get auth token from localStorage
const getAuthToken = () => {
  return localStorage.getItem('tenantHub_token');
};

// Create headers with auth token
const createHeaders = (includeAuth = true) => {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };

  if (includeAuth) {
    const token = getAuthToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
  }

  return headers;
};

// Generic API request function
const apiRequest = async (endpoint: string, options: RequestInit = {}) => {
  const url = `${API_BASE_URL}${endpoint}`;
  
  const config: RequestInit = {
    ...options,
    headers: {
      ...createHeaders(),
      ...options.headers
    }
  };

  try {
    console.log(`Making API request to: ${url}`);
    const response = await fetch(url, config);
    
    if (!response.ok) {
      let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
      try {
        const errorData = await response.json();
        errorMessage = errorData.message || errorMessage;
      } catch (parseError) {
        console.error('Error parsing error response:', parseError);
      }
      throw new Error(errorMessage);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('API request error:', error);
    throw error;
  }
};

// Complaints API
export const complaintsAPI = {
  getAll: (params?: Record<string, any>) => {
    const queryString = params ? '?' + new URLSearchParams(params).toString() : '';
    return apiRequest(`/complaints${queryString}`);
  },
  
  getById: (id: string) => apiRequest(`/complaints/${id}`),
  
  create: (complaintData: any) => apiRequest('/complaints', {
    method: 'POST',
    body: JSON.stringify(complaintData)
  }),
  
  update: (id: string, updateData: any) => apiRequest(`/complaints/${id}`, {
    method: 'PUT',
    body: JSON.stringify(updateData)
  }),
  
  delete: (id: string) => apiRequest(`/complaints/${id}`, {
    method: 'DELETE'
  }),
  
  uploadImages: (id: string, formData: FormData) => {
    const token = getAuthToken();
    return fetch(`${API_BASE_URL}/complaints/${id}/images`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
      },
      body: formData
    }).then(res => {
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      }
      return res.json();
    });
  }
};

// Rent API
export const rentAPI = {
  getAll: (params?: Record<string, any>) => {
    const queryString = params ? '?' + new URLSearchParams(params).toString() : '';
    return apiRequest(`/rent${queryString}`);
  },
  
  getCurrent: () => apiRequest('/rent/current'),
  
  create: (rentData: any) => apiRequest('/rent', {
    method: 'POST',
    body: JSON.stringify(rentData)
  }),
  
  uploadPaymentProof: (id: string, formData: FormData) => {
    const token = getAuthToken();
    return fetch(`${API_BASE_URL}/rent/${id}/payment-proof`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
      },
      body: formData
    }).then(res => {
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      }
      return res.json();
    });
  },
  
  verify: (id: string, verificationData: any) => apiRequest(`/rent/${id}/verify`, {
    method: 'PUT',
    body: JSON.stringify(verificationData)
  }),
  
  getStats: () => apiRequest('/rent/stats')
};

// Notices API
export const noticesAPI = {
  getAll: (params?: Record<string, any>) => {
    const queryString = params ? '?' + new URLSearchParams(params).toString() : '';
    return apiRequest(`/notices${queryString}`);
  },
  
  getById: (id: string) => apiRequest(`/notices/${id}`),
  
  create: (noticeData: any) => apiRequest('/notices', {
    method: 'POST',
    body: JSON.stringify(noticeData)
  }),
  
  update: (id: string, updateData: any) => apiRequest(`/notices/${id}`, {
    method: 'PUT',
    body: JSON.stringify(updateData)
  }),
  
  delete: (id: string) => apiRequest(`/notices/${id}`, {
    method: 'DELETE'
  })
};

// Users API
export const usersAPI = {
  getAll: (params?: Record<string, any>) => {
    const queryString = params ? '?' + new URLSearchParams(params).toString() : '';
    return apiRequest(`/users${queryString}`);
  },
  
  getById: (id: string) => apiRequest(`/users/${id}`),
  
  update: (id: string, updateData: any) => apiRequest(`/users/${id}`, {
    method: 'PUT',
    body: JSON.stringify(updateData)
  }),
  
  updateStatus: (id: string, statusData: any) => apiRequest(`/users/${id}/status`, {
    method: 'PUT',
    body: JSON.stringify(statusData)
  }),
  
  delete: (id: string) => apiRequest(`/users/${id}`, {
    method: 'DELETE'
  }),
  
  getStats: () => apiRequest('/users/stats/overview')
};

export default {
  complaints: complaintsAPI,
  rent: rentAPI,
  notices: noticesAPI,
  users: usersAPI
};